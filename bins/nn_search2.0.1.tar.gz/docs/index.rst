.. nn_search2 documentation master file, created by
   sphinx-quickstart on Fri Mar 11 23:47:43 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to nn_search2's documentation!
======================================

Contents:

.. toctree::

  installation.rst
  howto.rst
  statistics.rst
  nn_search2.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

